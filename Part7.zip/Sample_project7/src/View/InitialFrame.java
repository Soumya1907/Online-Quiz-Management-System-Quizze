/*
 * SOUMYA'S PROJECT
 * PLEASE DONOT COPY  * CALL 8420762376 FOR UNDERSTAND AND THEN DO IT YOURSELF
 */
package View;

import javax.swing.*;
import java.awt.*;

/**
 *
 * @author Soumya
 */
public class InitialFrame {
   
   private InitialPanel initialpanel;
   private JFrame initialframe;
   
   public InitialFrame()
   {      
      initialframe = new JFrame("Soumya's Table Viewer");
      initialframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      initialframe.setExtendedState(JFrame.MAXIMIZED_BOTH);
      initialframe.setVisible(true);
      initialpanel = new InitialPanel(initialframe);
   }
      
 
   public InitialPanel getInitialPanel()
   {
      return initialpanel;
   }
   

   public JFrame getInitialFrame()
   {
      return initialframe;
   }


   public void setInitialPanel(InitialPanel initialpanel)
   {
      this.initialpanel = initialpanel;
   }
   

   public void setInitialFrame(JFrame initialframe)
   {
      this.initialframe = initialframe;
   }
           
   
}
