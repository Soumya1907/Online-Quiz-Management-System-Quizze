
/*
 * SOUMYA'S PROJECT
 * PLEASE DONOT COPY  * CALL 8420762376 FOR UNDERSTAND AND THEN DO IT YOURSELF
 */
package View;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.*;

/**
 *
 * @author Soumya
 */
public class WestPanel implements ActionListener {
   
   private JPanel westpanel;
   private CenterPanel centerpanel;
   private JLabel JLab;
   private JButton choice;
   private JButton selectionSort;
   private JButton mergeSort;
   private JButton quickSort;
   
   private int sortType;
   
   private Model.FootballPlayerData FpData;
   
   private View view;
   
   private Controller.Controller controller;
      
   public WestPanel(JPanel initialpanel, CenterPanel centerpanel)
   {
      westpanel = new JPanel();
      
      choice = new JButton("Choose a SORT type : ");
      selectionSort = new JButton("Selection Sort/\nSelf Implemented");
      mergeSort = new JButton("Merge Sort/ArrayList()");
      quickSort = new JButton("Quick Sort/Arrays[]");
      
      initialpanel.add(westpanel, BorderLayout.WEST);
      westpanel.setPreferredSize(new Dimension(250, 250));
      westpanel.setLayout(new GridLayout(4, 1));
      
      westpanel.add(choice);
      choice.setBackground(Color.LIGHT_GRAY);
      
      westpanel.add(selectionSort);
      selectionSort.setBackground(Color.MAGENTA);
      
      westpanel.add(mergeSort);
      mergeSort.setBackground(Color.cyan);
      
      westpanel.add(quickSort);   
      quickSort.setBackground(Color.PINK);    
      
      selectionSort.addActionListener(this);
      quickSort.addActionListener(this);
      mergeSort.addActionListener(this);
      
      this.centerpanel = centerpanel;
   }
   
   /**
    *
    * Accessor for westpanel reference variable with an attribute
    * of type JPanel.
    * 
    * @return the JPanel associated with the WestPanel
    */
   public JPanel getWestPanel()
   {
      return westpanel;
   }
   
   public int getSortType()
   {
      return sortType;
   }
   
   public void setSortType(int sortType)
   {
      this.sortType = sortType;
   }
   
   public void setFpData(Model.FootballPlayerData FpData)
   {
      this.FpData = FpData;
   }
   
   public void setView(View view)
   {
      this.view = view;
   }
   
   public void setController(Controller.Controller controller)
   {
      this.controller = controller;
   }
   
   @Override
   public void actionPerformed(ActionEvent actionEvent)
   {      
      if(selectionSort.getText().equals(actionEvent.getActionCommand()))
      {
         sortType = 1;
      }
      else if(quickSort.getText().equals(actionEvent.getActionCommand()))
      {
         sortType = 3;
      }
      else if(mergeSort.getText().equals(actionEvent.getActionCommand()))
      {
         sortType = 2;
      }
      
      FpData.sort(sortType, centerpanel.getSortField());
      view.CenterUpdate(FpData.getLines(controller.getFirstLine(), controller.getLastLine()), FpData.getHeaders());
      centerpanel.getCenterPanel().repaint();
      centerpanel.getCenterPanel().validate();
   }
   
}
