/*
 * SOUMYA'S PROJECT
 * PLEASE DONOT COPY  * CALL 8420762376 FOR UNDERSTAND AND THEN DO IT YOURSELF
 */
package View;

import javax.swing.*;
import java.awt.*;

/**
 *
 * @author Soumya
 */
public class InitialPanel {
   
   private CenterPanel centerpanel;
   private WestPanel westpanel;
   
   private JPanel initialpanel;
   private JPanel northpanel;
   private JPanel southpanel;
   
   private JLabel northlabel;
   private JLabel southlabel;
      
   public InitialPanel(JFrame initialframe)
   {
      initialpanel = new JPanel();
      initialpanel.setLayout(new BorderLayout());
      
      initialframe.add(initialpanel);
      
      northpanel = new JPanel();
      northpanel.setBackground(Color.WHITE);
      northlabel = new JLabel("North Panel");
      northlabel.setForeground(Color.BLACK);
      northpanel.add(northlabel);
      
      initialpanel.add(northpanel, BorderLayout.NORTH);
      
      southpanel = new JPanel();
      southpanel.setBackground(Color.BLACK);
      southlabel = new JLabel("South Panel");
      southlabel.setForeground(Color.white);      
      southpanel.add(southlabel);   

      initialpanel.add(southpanel, BorderLayout.SOUTH);      
      
      centerpanel = new CenterPanel(initialpanel);
      westpanel = new WestPanel(initialpanel, centerpanel);
   }
      
   /**
    *
    * Accessor to get the CenterPanel JPanel.
    * 
    * @return returns the JPanel of CenterPanel
    */
   public JPanel getCp()
   {
      return centerpanel.getCenterPanel();
   }
   
   /**
    *
    * Accessor for centerpanel attribute.
    * 
    * @return returns an attribute of type CenterPanel
    */
   public CenterPanel getCenterPanel()
   {
      return centerpanel;
   }

   /**
    *
    * Accessor for initialpanel attribute.
    * 
    * @return returns an attribute of type JPanel
    */
   public JPanel getInitialPanel()
   {
      return initialpanel;
   }

   /**
    *
    * Mutator to set the CenterPanel JPanel.
    * 
    * @param centerpanel parameter of type JPanel to set the centerpanel
    */
   public void setCp(JPanel centerpanel)
   {
      this.centerpanel.setCenterPanel(centerpanel);
   }
   
   /**
    *
    * Mutator for centerpanel attribute.
    * 
    * @param centerpanel parameter of type CenterPanel
    */
   public void setCenterPanel(CenterPanel centerpanel)
   {
      this.centerpanel = centerpanel;
   }

   /**
    *
    * Mutator for initialpanel attribute.
    * 
    * @param initialpanel parameter of type JPanel to set the initialpanel
    */
   public void setInitialPanel(JPanel initialpanel)
   {
      this.initialpanel = initialpanel;
   }
   
   /**
    *
    * Accessor for westpanel reference variable with an attribute
    * of type WestPanel.
    * 
    * @return the reference variable associated with the WestPanel
    */
   public WestPanel getWestPanel()
   {
      return westpanel;
   }
   
}
