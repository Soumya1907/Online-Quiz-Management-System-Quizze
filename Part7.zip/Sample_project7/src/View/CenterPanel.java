/*
 * SOUMYA'S PROJECT
 * PLEASE DONOT COPY  * CALL 8420762376 FOR UNDERSTAND AND THEN DO IT YOURSELF
 */
package View;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

/**
 *
 * @author Soumya
 */
public class CenterPanel implements ActionListener {
   
   private JPanel centerpanel;
   
   private ArrayList<JButton> headerButtons;
   private ArrayList<ArrayList<JButton>> lineButtons;
   
   private int sortField = -1;
      
   public CenterPanel(JPanel initialpanel)
   {
      centerpanel = new JPanel();
      initialpanel.add(centerpanel);
      centerpanel.setBackground(Color.BLACK);
      headerButtons = new ArrayList<>();
      lineButtons = new ArrayList<>();
   }
   
 
   public void createButtons(int linesBeingDisplayed, int headerSize)
   {
      centerpanel.setLayout(new GridLayout(linesBeingDisplayed + 1, headerSize, 2, 2));
            
      ArrayList<JButton> lineButtonRow;
            
      for(int i = 0 ; i < headerSize ; i++ )
      {
         JButton headerButton = new JButton();
         headerButton.setBackground(Color.LIGHT_GRAY);
         centerpanel.add(headerButton);         
         headerButtons.add(headerButton);
      }
      
      for(int i = 0 ; i < linesBeingDisplayed ; i++)
      {         
         lineButtonRow = new ArrayList<>();
         
         for(int j = 0 ; j < headerSize ; j++)
         {
            JButton lineButton = new JButton();
            centerpanel.add(lineButton);
            lineButtonRow.add(lineButton);
         }
         
         lineButtons.add(lineButtonRow);         
      }  
   }
      

   public void setButtonsData(ArrayList<ArrayList<String>> data, ArrayList<String> headers)
   {
      for(int i = 0 ; i < data.size() ; i++)
      {
         for(int j = 0 ; j < headers.size() ; j++)
         {
            lineButtons.get(i).get(j).setText(data.get(i).get(j));
         }
      }
      
      for(int i = 0 ; i < headers.size() ; i++)
      {
         headerButtons.get(i).setText(headers.get(i));
         headerButtons.get(i).addActionListener(this);
      }
   }
 
   public JPanel getCenterPanel()
   {
      return centerpanel;
   }

   public void setCenterPanel(JPanel centerpanel)
   {
      this.centerpanel = centerpanel;
   }
   
  
   public ArrayList<JButton> getheaderButtons()
   {
      return headerButtons;
   }
  
   public void setheaderButtons(ArrayList<JButton> headerButtons)
   {
      this.headerButtons = headerButtons;
   }
   
   
   public ArrayList<ArrayList<JButton>> getlineButtons()
   {
      return lineButtons;
   }
   
   
   public void setlineButtons(ArrayList<ArrayList<JButton>> lineButtons)
   {
      this.lineButtons = lineButtons;
   }

   public void setSortField(int sortField)
   {
      this.sortField = sortField;
   } 
   
   public int getSortField()
   {
      return sortField;
   }

   
   @Override
   public void actionPerformed(ActionEvent actionEvent)
   {
      for(JButton button : headerButtons)
      {
         if(button.getText().equals(actionEvent.getActionCommand()))
         {
            button.setBackground(Color.blue);
            button.setForeground(Color.white);
            sortField = headerButtons.indexOf(button);
            System.out.println(sortField);
         }
         else
         {
            button.setForeground(Color.black);
            button.setBackground(Color.RED);
         }
      }
   }
   
}
