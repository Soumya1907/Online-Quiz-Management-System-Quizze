/*
 * SOUMYA'S PROJECT
 * PLEASE DONOT COPY  * CALL 8420762376 FOR UNDERSTAND AND THEN DO IT YOURSELF
 */
package Model;

/**
 *
 * @author intelligence
 */
public interface Displayable {
   
   public int getFirstLineToDisplay();
   
   public void setFirstLineToDisplay(int firstLine);
   
   public int getLineToHighlight();
   
   public void setLineToHighlight(int highlightedLine);
   
   public int getLastLineToDisplay();
   
   public void setLastLineToDisplay(int lastLine);
   
   public int getLinesBeingDisplayed();
   
   public void setLinesBeingDisplayed(int numberOfLines);
   
}
